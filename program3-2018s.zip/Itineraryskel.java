// Airline Travel Scheduler - Itinerary
// Bongki Moon (bkmoon@snu.ac.kr)

public class Itinerary
{

  // constructor
  Itinerary(...) {}

  public boolean isFound() {}

  public void print() {}

}
