// Airline Travel Scheduler - Planner
// Bongki Moon (bkmoon@snu.ac.kr)

public class Planner {

  // constructor
  public Planner(LinkedList<Airport> portList, LinkedList<Flight> fltList) {}

  public Itinerary Schedule(String start, String end, String departure) {}

}

