// Airline Travel Scheduler - Flight
// Bongki Moon (bkmoon@snu.ac.kr)

public class Flight
{

  // constructor
  public Flight(String src, String dest, String stime, String dtime) {}

  public void print() {}

}
