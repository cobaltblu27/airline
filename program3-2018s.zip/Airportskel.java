// Airline Travel Scheduler - Airport
// Bongki Moon (bkmoon@snu.ac.kr)

import java.io.*;
import java.util.*;

public class Airport
{

  public Airport(String port, String connectTime) {}	// constructor

  public void print() {}

}
